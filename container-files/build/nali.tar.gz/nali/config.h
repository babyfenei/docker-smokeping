#define NALI_QQWRY_PATH "/usr/local/share/QQWry.Dat"
